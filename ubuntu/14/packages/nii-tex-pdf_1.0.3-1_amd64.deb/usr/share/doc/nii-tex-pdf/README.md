# tex-pdf > master

### HOW TO USE

#### Install nii-tex-pdf.repo
    $ vi /etc/yum.repos.d
  
    [tex-pdf-git]
    name=CentOS-$releasever - tex-pdf
    baseurl=https://ryukaku3.github.io/tex-pdf/
    enabled=0
    gpgcheck=0
    #gpgcheck=1
    #gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-6

### ABOUT Markdown 
    https://help.github.com/articles/writing-on-github/
    http://codechord.com/2012/01/readme-markdown/
